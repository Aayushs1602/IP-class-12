from newsapi import NewsApiClient

# Init
newsapi = NewsApiClient(api_key='18d4d239957f4ed9b5dd8ecb8308dd09')

# /v2/top-headlines
top_headlines = newsapi.get_top_headlines(sources='bbc-news, the-verge')

#for z in top_headlines["articles"]:
#    print(z['title'], z['description'], z['url'], z["urlToImage"], z, sep='\n', end='\n\n\n')



sources = newsapi.get_sources()
for z in sources['sources']:
    print(z["id"], z['country'])
